# Admin booking form: voucher recalculation + validation messages

Problem: pasting a code (e.g. BIG9999) into the Voucher code field did nothing until the field lost focus, and when it could not be applied
(no service / date / time yet, or a fixed amount larger than the sub-total) there was no explanation.

- app/web/js/pjAdminBookings.js: typing or pasting a code recalculates at once (input/paste/keyup, debounced); one message at a time under the field:
  not valid for the date/time | select the service(s), date and time first | discount limited to the sub-total (amount bigger than the sub-total is capped, total 0.00).
- app/views/pjAdminBookings/pjActionCreate.php, pjActionUpdate.php: the two new message holders (dynamic labels).
- app/config/updates/update_2026_11_05_15_00_00.sql: run once. Adds the labels lblBookingVoucherNeedData and lblBookingVoucherCapped and refreshes the label cache.
  (Add-on to update_2026_11_05_13_00_00.sql, which must already have been run.)
