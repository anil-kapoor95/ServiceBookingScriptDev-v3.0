# Voucher Apply/Remove button text centring

- app/web/css/style.css: the voucher button inherited the theme top padding, which pushed its label to the bottom. Padding is now 0 and line-height equals the button height (44px), so the label is vertically centred in all themes.
